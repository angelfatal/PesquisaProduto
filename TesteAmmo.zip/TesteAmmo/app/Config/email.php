<?php
/**
 * This is email configuration file.
 *
 * Use it to configure email transports of Cake.
 *
 * PHP 5
 *
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Config
 * @since         CakePHP(tm) v 2.0.0
 */

/**
 * Email configuration class.
 * You can specify multiple configurations for production, development and testing.
 *
 * transport => The name of a supported transport; valid options are as follows:
 *		Mail		- Send using PHP mail function
 *		Smtp		- Send using SMTP
 *		Debug		- Do not send the email, just return the result
 *
 * You can add custom transports (or override existing transports) by adding the
 * appropriate file to app/Network/Email. Transports should be named 'YourTransport.php',
 * where 'Your' is the name of the transport.
 *
 * from =>
 * The origin email. See CakeEmail::from() about the valid values
 *
 */
class EmailConfig {

	public $default = array(
		//'transport' => 'Mail',
		//'from' => 'gsa@gsasolucoes.com.br',//'you@localhost',
		//'charset' => 'utf-8',
		//'headerCharset' => 'utf-8',
		
		'transport' => 'smtp',
		'from' => array('financeiro2@aguadoce.com.br' => 'Água Doce'),
		'host' => 'mail.lexxa.com.br',
		'port' => 587,
		'timeout' => 30,
		'username' => 'financeiro2@aguadoce.com.br',
		'password' => 'financeiro11',
		'client' => null,
		'log' => true,
		'delivery' => 'smtp'
	);     

	/*public $smtp = array(
		'transport' => 'smtp',
		'from' => array('gsa@gsasolucoes.com.br' => 'GSA Soluções'),
		'host' => 'smtp.gsasolucoes.com.br',
		'port' => 587,
		//'timeout' => 30,
		'username' => 'gsa@gsasolucoes.com.br',
		'password' => 'a27dm.as76g',
		'client' => null,
		'log' => false,
		//'charset' => 'utf-8',
		//'headerCharset' => 'utf-8',
	);

	public $fast = array(
		'from' => 'gsa@gsasolucoes.com.br',
		'sender' => null,
		'to' => null,
		'cc' => null,
		'bcc' => null,
		'replyTo' => null,
		'readReceipt' => null,
		'returnPath' => null,
		'messageId' => true,
		'subject' => null,
		'message' => null,
		'headers' => null,
		'viewRender' => null,
		'template' => false,
		'layout' => false,
		'viewVars' => null,
		'attachments' => null,
		'emailFormat' => null,
		'transport' => 'Smtp',
		'host' => 'smtp.gsasolucoes.com.br',
		'port' => 587,
		'timeout' => 30,
		'username' => 'gsa@gsasolucoes.com.br',
		'password' => 'a27dm.as76g',
		'client' => null,
		'log' => true,
		//'charset' => 'utf-8',
		//'headerCharset' => 'utf-8',
	);*/

}
