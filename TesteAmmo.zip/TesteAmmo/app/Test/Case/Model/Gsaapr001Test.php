<?php
App::uses('Gsaapr001', 'Model');

/**
 * Gsaapr001 Test Case
 *
 */
class Gsaapr001Test extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.gsaapr001'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Gsaapr001 = ClassRegistry::init('Gsaapr001');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Gsaapr001);

		parent::tearDown();
	}

}
