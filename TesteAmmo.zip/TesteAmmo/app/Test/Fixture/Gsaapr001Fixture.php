<?php
/**
 * Gsaapr001Fixture
 *
 */
class Gsaapr001Fixture extends CakeTestFixture {

/**
 * Table name
 *
 * @var string
 */
	public $table = 'gsaapr001';

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'idModulo' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'primary'),
		'ordem' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 10, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'descricaoTecnica' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 40, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'descricaoFuncional' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 40, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'descricaoReduzida' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 20, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'subModulo' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 3, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'idModuloPrincipal' => array('type' => 'integer', 'null' => true, 'default' => null),
		'situacao' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 2, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'idModulo', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'idModulo' => 1,
			'ordem' => 'Lorem ip',
			'descricaoTecnica' => 'Lorem ipsum dolor sit amet',
			'descricaoFuncional' => 'Lorem ipsum dolor sit amet',
			'descricaoReduzida' => 'Lorem ipsum dolor ',
			'subModulo' => 'L',
			'idModuloPrincipal' => 1,
			'situacao' => ''
		),
	);

}
