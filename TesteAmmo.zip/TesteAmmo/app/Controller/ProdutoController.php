<?php
App::uses('CakeEmail', 'Network/Email');

class ProdutoController extends AppController {
    
    //var $name = 'gsaper001';
    public $components = array('Paginator');

       
/**
 * index method
 *
 * @return void
 */
	public function index() {                       
                        
            
        if ($this->request->is('get')) {  
            
            $campo    = (isset($this->params->query['campo']))?($this->params->query['campo']):('Produto.nome');        
            $pesquisa = (isset($this->params->query['pesquisa']))?($this->params->query['pesquisa']):('');        
            $limite = (isset($this->params->query['limite']))?($this->params->query['limite']):(10);
            
            $this->Paginator->settings = array(
                                                    'conditions' => array($campo.' LIKE' => '%'.$pesquisa.'%'),
                                                    'limit' => $limite
                                                );                

        } 



        $this->Produto->recursive = 1;
        //pr($this->Paginator->paginate()); exit;
        $this->set('Produtos', $this->Paginator->paginate());  
	}
        
   
 
}
