<?php
App::uses('AppModel', 'Model');
/**
 * Gsaper001 Model
 *
 */
class ProdutoFoto extends AppModel {
    
/**
 * Use table
 *
 * @var mixed False or table name
 */
        //var $name = 'gsaper001';
        var $useTable = 'produto_foto';
       
        
/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'idProdutoFK';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'foto';
              
        

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'idProduto' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			
		),		
		
                
            
                
	);        
}
