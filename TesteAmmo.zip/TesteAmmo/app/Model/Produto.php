<?php
App::uses('AppModel', 'Model');
/**
 * Gsaper001 Model
 *
 */
class Produto extends AppModel {
    
/**
 * Use table
 *
 * @var mixed False or table name
 */
        //var $name = 'gsaper001';
        var $useTable = 'produto';
	   
        public $hasMany = array('ProdutoFoto'=> array(
			'foreignKey' => 'idProdutoFK',
			'dependent' => true
			)    
		);
        
/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'idProduto';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'descricao';
              
        

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'idProduto' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			
		),		
		
                
            
                
	);        
}
