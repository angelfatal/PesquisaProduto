<?php
/**
 * Application model for Cake.
 *
 * This file is application-wide model file. You can put all
 * application-wide model-related methods here.
 *
 * PHP 5
 *
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Model
 * @since         CakePHP(tm) v 0.2.9
 */

App::uses('Model', 'Model');

/**
 * Application model for Cake.
 *
 * Add your application-wide methods in the class below, your models
 * will inherit them.
 *
 * @package       app.Model
 */
class AppModel extends Model {    
    //public $actsAs = array('DataPtBr');
    public $actsAs = array('CakePtbr.AjusteData');
    //var $actsAs = array('DataPtBr', 'CakePtbr.AjusteData'); // , 'Locale.Locale'
    //var $actsAs = array('CakePtbr.AjusteData' => 'campo_data'); // Segundo caso
    //var $actsAs = array('CakePtbr.AjusteData' => array('publicado', 'informado')); // Terceiro caso
    
}
